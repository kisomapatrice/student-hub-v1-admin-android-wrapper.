STUDENT HUB ADMIN V1 — FRESH START KIT 2.0.0

This kit is designed for a BRAND-NEW GitHub repository. It does not edit the live Student Hub site, any database, the AI Worker, or the older installed Android app.

RECOMMENDED NEW REPOSITORY NAME
student-hub-v1-admin-android-wrapper

FILES IN THIS KIT
1) student-hub-v1-admin-android-source-2.0.0.zip
   The clean Android project source. Upload this ZIP to the ROOT of the new GitHub repository. Keep the filename exactly as shown.

2) build-student-hub-v1-admin-apk-2.0.0.yml
   The GitHub Actions build workflow. In the new repository, create a new file with this exact path:
   .github/workflows/build-apk.yml
   Open the downloaded .yml file as text and copy all its contents into the GitHub file editor. Commit the new file to the default branch.

3) student-hub-v1-admin-android-source-2.0.0.zip.sha256
   A source-bundle checksum reference.

4) Student_Hub_Admin_V1_Icon_2.0.0.png
   Preview of the app icon included in the Android project.

CREATE THE REPOSITORY
1. Open https://github.com/new and create a repository named student-hub-v1-admin-android-wrapper.
2. Choose Private for the initial build project. Leave “Add a README” unchecked so the repository starts empty.
3. In the empty repository, use Add file → Upload files and upload student-hub-v1-admin-android-source-2.0.0.zip to the repository root; commit the upload.
4. Use Add file → Create new file. For the filename/path, enter .github/workflows/build-apk.yml. Paste all contents of build-student-hub-v1-admin-apk-2.0.0.yml into the editor and commit.
5. Open the Actions tab. Select “Build Student Hub Admin V1 Android APK,” choose Run workflow, then Run workflow again to confirm.
6. If the build succeeds, open the completed run and download the artifact named Student-Hub-Admin-V1-2.0.0-verified-APK. The artifact ZIP contains the APK and SHA-256 file.
7. Extract the artifact ZIP on the phone and tap Student-Hub-Admin-V1-2.0.0-debug.apk to install.

IMPORTANT SAFETY RULES
- Keep the older working app installed during testing. The new app uses a different package ID so it can be tested alongside the older app.
- This app opens ONLY the Student Hub V1 admin URL on student-hub.great-site.net. It must not be switched to the separate V2 site.
- Do not upload passwords, database credentials, API keys, signing keys, or tokens.
- If any build fails, open the failed step logs and read the first explicit ERROR line. Do not repeat the same run without identifying the reason.

NEW APP DETAILS
Label: Student Hub Admin V1
Wrapper version: 2.0.0
Package: ug.studenthub.adminv1.app200
Starting URL: https://student-hub.great-site.net/admin/CONSOLE/index.php?module=dashboard
Minimum Android API: 23 (Android 6)
Private sideload test APK; not packaged as a Play Store release.
