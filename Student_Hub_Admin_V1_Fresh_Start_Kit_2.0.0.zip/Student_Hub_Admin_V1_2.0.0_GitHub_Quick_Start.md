# Student Hub Admin V1 Android Wrapper 2.0.0 — Quick Start

This is a fresh, separate build project. It does **not** modify the live website, database, AI worker or prior Android app.

## New repository
Name: `student-hub-v1-admin-android-wrapper`

Recommended initial visibility: **Private**.

## Upload the source bundle
Upload `student-hub-v1-admin-android-source-2.0.0.zip` to the repository root. Keep its exact filename.

## Add the workflow file
Create `.github/workflows/build-apk.yml` on the default branch and paste the complete contents of `build-student-hub-v1-admin-apk-2.0.0.yml`.

## Run and download
Open **Actions** → **Build Student Hub Admin V1 Android APK** → **Run workflow**. The job diagnoses the source bundle, builds the Android app, rejects unexpectedly tiny APKs, verifies APK ZIP integrity and Android signature, and confirms package/version metadata. A successful run uploads `Student-Hub-Admin-V1-2.0.0-verified-APK` for 14 days.

## App safeguards
- V1-only URL allowlist: `student-hub.great-site.net`
- New package ID: `ug.studenthub.adminv1.app200`, to keep the prior app separate during testing
- No embedded credentials, auth bypass, TLS bypass or cleartext traffic
- File picker, same-host downloads, navigation history, retry UI and branded launcher icon

The CI artifact is a debug-signed private sideload test APK, not a Google Play release build.
