# QA checklist — before installing the new APK

## CI artifact
- [ ] GitHub Actions run finishes successfully.
- [ ] Artifact contains `Student-Hub-Admin-V1-2.0.0-debug.apk` and its `.sha256` file.
- [ ] APK is not a tiny placeholder; workflow checks its size and signature.
- [ ] Package is exactly `ug.studenthub.adminv1.app200`, version `2.0.0`.

## Samsung Android device
- [ ] Keep the older working app installed.
- [ ] Install the new APK alongside it.
- [ ] Launch icon says Student Hub Admin V1 and displays the education mark.
- [ ] Launch opens the V1 Admin Console login/dashboard URL over HTTPS.
- [ ] Login continues to be handled by the website.
- [ ] Refresh/retry behavior works on weak internet.
- [ ] App back navigation returns through website pages.
- [ ] File upload chooser opens for a form that requires an attachment.
- [ ] Download initiated by the V1 site appears in Android Downloads.
- [ ] External links open outside the wrapper.
- [ ] Turn off data or Wi‑Fi briefly: app shows a retry message and does not crash.
- [ ] HTTPS certificate errors are never bypassed.

If any test fails, keep the old app and record the exact message before changing source.
