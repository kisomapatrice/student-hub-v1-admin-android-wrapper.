# Engineering handover — Student Hub Admin V1 Android Wrapper 2.0.0

## Fixed identifiers

- Repository target name: `student-hub-v1-admin-android-wrapper`
- App label: `Student Hub Admin V1`
- App package: `ug.studenthub.adminv1.app200`
- Version: `2.0.0` / versionCode `200`
- V1 start URL: `https://student-hub.great-site.net/admin/CONSOLE/index.php?module=dashboard`
- Allowed in-app HTTPS host: `student-hub.great-site.net`

## Why the package ID is new

The package ID is deliberately different from earlier APKs. This allows safe side-by-side testing without asking the user to uninstall the known-working app or overwrite its local app data.

## Main files

- `app/src/main/java/ug/studenthub/adminapp/MainActivity.java`: startup overlay, WebView configuration, URL policy, file uploads, downloads, loading/errors, back navigation and cookie lifecycle.
- `app/src/main/AndroidManifest.xml`: required app permissions and launcher activity.
- `app/src/main/res/drawable/ic_launcher_foreground.xml`: adaptive launcher mark.
- `app/src/main/res/drawable/ic_launcher_monochrome.xml`: Android themed-icon mark.
- `app/src/main/res/mipmap-*/ic_launcher.png`: raster fallback assets for older launchers.
- `app/build.gradle`: app identity, SDK levels and version.

## Guardrails

1. Never embed credentials or tokens in app source.
2. Never bypass website login, role checks, CSRF, rate limits, or auditing.
3. Never weaken TLS validation or enable cleartext traffic.
4. Never broaden the allowed in-app host without a documented need and review.
5. Never mix the V1 deployment with the separate V2 site, database, or AI worker.
6. Keep the existing known-working app installed until the new artifact is verified on-device.

## Verification gates

The CI workflow must not publish an APK unless the file is nonempty and larger than the expected minimum, passes ZIP integrity validation, passes `apksigner verify`, and matches the expected package and version reported by Android build tools.
