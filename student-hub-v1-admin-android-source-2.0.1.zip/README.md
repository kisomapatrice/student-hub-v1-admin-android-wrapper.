# Student Hub Admin V1 — Android Wrapper 2.0.1

A small, security-conscious Android WebView app for the existing **Student Hub V1 Admin Console** at `https://student-hub.great-site.net/admin/CONSOLE/index.php?module=dashboard`.

## What this app does

- Opens the V1 Admin Console directly; normal website sign-in and server-side permissions remain in force.
- Shows a branded launch screen, loading progress, and a retry message when the site cannot be reached.
- Keeps web session cookies on device so the normal website login can work.
- Supports file pickers for forms that upload files and Android Download Manager for downloads from the approved V1 host.
- Sends unrelated web links to the Android browser instead of silently navigating away inside the admin app.
- Refuses cleartext HTTP and never bypasses HTTPS certificate errors.
- Includes an education-themed student/graduation-cap app icon and adaptive/monochrome launcher variants.
- Includes no embedded passwords, API keys, database credentials, or admin bypasses.

## Hard separation rule

This package points only to the Student Hub **V1** host `student-hub.great-site.net`. Do not change it to the separate V2 site, and do not add V2 URLs, keys, databases, or workers to this repository.

## Build

The source is intended for a clean GitHub repository and a GitHub Actions workflow. The workflow builds a debug-signed APK for private sideload testing, then checks ZIP integrity, Android signature, package ID, version, and file size before publishing the artifact.

- App label: `Student Hub Admin V1`
- Wrapper version: `2.0.1`
- Application ID: `ug.studenthub.adminv1.app200` (intentionally distinct from previous installs)
- Minimum Android: 6.0 (API 23)
- Compile SDK: 36
- Target SDK: 34 (private sideload test build; not configured as a Play Store release)

## Security notes

The website owns authentication, access control, CSRF protections, and all data operations. This wrapper does not replace or weaken them. Do not add secrets to this repository. App code and release artifacts are not a substitute for server-side authorization.
