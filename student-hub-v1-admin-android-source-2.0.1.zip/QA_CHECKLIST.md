STUDENT HUB ADMIN V1 — VERSION 2.0.1 QA CHECKLIST

Static checks included in this package:
- Same package ID as working 2.0.0 baseline: ug.studenthub.adminv1.app200
- Version bumped from 200/2.0.0 to 201/2.0.1 for in-place update
- Same V1-only Admin Console URL and host allowlist
- Refreshed launcher bitmap densities, adaptive foreground, and monochrome launcher art
- Zoom/pinch remains enabled for accessibility on phone screens
- No website, PHP, database, credential, role, or worker changes

Not yet verified:
- GitHub Actions compilation of 2.0.1
- Android update installation over signed 2.0.0 on Samsung A06
- Final icon appearance on the actual launcher
- Final screen, navigation, login, upload/download after update

Release gate: keep Version 2.0.0 installed and usable until the 2.0.1 APK builds, installs as an update, and the listed device tests pass.
