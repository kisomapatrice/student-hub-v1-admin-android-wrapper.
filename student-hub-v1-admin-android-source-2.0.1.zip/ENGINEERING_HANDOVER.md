# Student Hub Admin V1 Android — Version 2.0.1 appearance update

This source bundle is based on the user's successfully installed Version 2.0.0 wrapper.

## Changes
- Refined the navy/blue/gold Student Hub launcher icon: graduation cap + open book, with adaptive foreground and monochrome assets.
- Updated launcher PNG densities and the startup screen build label to 2.0.1.
- Bumped versionCode to 201 and versionName to 2.0.1 so this can update package `ug.studenthub.adminv1.app200` rather than install as a separate app.
- Preserved the V1-only URL/host allowlist, website login, file handling, back navigation, and WebView zoom/pinch controls.
- No PHP, SQL, website, or Cloudflare Worker files are part of this update.

## Important
The existing repository workflow must also be updated to the paired `build-student-hub-v1-admin-apk-2.0.1.yml` workflow. It expects `student-hub-v1-admin-android-source-2.0.1.zip` and verifies package `ug.studenthub.adminv1.app200`, versionCode 201, and versionName 2.0.1.

The APK build and on-device update have not yet been run for Version 2.0.1. Keep the installed 2.0.0 APK/working baseline until GitHub Actions succeeds and the update installs and is tested.
